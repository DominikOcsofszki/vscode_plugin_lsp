def main() -> None:
    print("Hello from jsq-lsp!")
